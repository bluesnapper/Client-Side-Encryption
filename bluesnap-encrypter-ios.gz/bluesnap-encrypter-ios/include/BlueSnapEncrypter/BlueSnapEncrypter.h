//
//  BlueSnapEncrypter.h
//  Copyright (c) 2014 BlueSnap. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <CommonCrypto/CommonCryptor.h>

@interface BlueSnapEncrypter : NSObject

@property (strong,nonatomic) NSString *publicKey;
@property (strong,nonatomic) NSData *AESKey;
@property (strong,nonatomic) NSData *HMAC;
@property (strong,nonatomic) NSArray  *PKParts;
@property (strong,nonatomic) NSString *publicExp,*modulus;
@property (strong,nonatomic) NSString * encryptedText;
@property SecKeyRef publicKeyRef;

-(id) initWithPublicKey:(NSString*)pk;
-(NSData*) generateAESKey;
-(NSData*) generateIV;
-(NSData*) generateHMACKey;
-(NSString*) encryptText:(NSString*)plainTxt;
@end


@interface BlueSnapSecKeyRef : NSObject

@property CCOptions typeOfSymmetricOpts;
- (SecKeyRef) addPeerPublicKey:(NSString *)peerName keyBits:(NSData *)publicKey;
- (void) removePeerPublicKey:(NSString *)peerName;
@end
